const passwrd = document.querySelector(".form input[type = 'password']"),
togbut = document.querySelector(".form .field i");

togbut.onclick = ()=>{
    if(passwrd.type == "password"){
        passwrd.type = "text";
        togbut.classList.add("active");
    }else{
        passwrd.type = "password";
        togbut.classList.remove("active");
    }
}