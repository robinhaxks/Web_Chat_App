userlist = document.querySelector(".user .user-list "),
searchbar = document.querySelector(".user .search input");


searchbar.onclick =()=>{
    let searchTrem =searchbar.value;
    if(searchTrem!= ""){
        searchbar.classList.add("active");
    }else{
        searchbar.classList.remove("active");
        searchbar.value = "";
    }
    let xhr  = new XMLHttpRequest();
    xhr.open("POST" , "php/search.php",true);
    xhr.onload = ()=>{
        if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                let data = xhr.response;
                userlist.innerHTML = data;
                
            }
        }
    }
    xhr.setRequestHeader("Content-type" , "application/x-www-form-urlencoded");
    xhr.send("searchTrem=" +searchTrem); 

}



setInterval(()=>{
    let xhr  = new XMLHttpRequest();
    xhr.open("GET" , "php/user.php",true);
    xhr.onload = ()=>{
        if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                let data = xhr.response;
                if(!searchbar.classList.contains("active")){
                    userlist.innerHTML = data;   
                }
                
            }
        }
    }
    xhr.send();    

},500);