<?php
   include_once "cong.php";
   $searchTrem = mysqli_real_escape_string($conn,$_POST["searchTrem"]);
   $output = "";
   $sql = mysqli_query($conn, "SELECT * FROM user WHERE fname LIKE '%{$searchTrem}' OR lname LIKE '%{$searchTrem}'");
   if(mysqli_num_rows($sql)>0){
       include "data.php";
       
   }else{
       $output .= "no user found in search term";
   }

   echo $output;
?>