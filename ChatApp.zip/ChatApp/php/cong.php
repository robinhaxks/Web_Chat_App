<?php
   $conn = mysqli_connect("localhost","root","","Chat");
   if($conn){
          mysqli_connect_error();
   }

?>