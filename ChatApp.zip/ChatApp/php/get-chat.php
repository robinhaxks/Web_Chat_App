<?php
    session_start();
    if(isset($_SESSION['unique_id'])){
        include_once "cong.php";
        $outgoing_id = mysqli_real_escape_string($conn,$_POST['outgoing_id']);
        $incoming_id = mysqli_real_escape_string($conn,$_POST['incoming_id']);
        $output = "";
        
        $sql = "SELECT * FROM messages 
                LEFT JOIN user ON user.unique_id = messages.incoming_id
                WHERE (outgoing_id={$outgoing_id} AND incoming_id = {$incoming_id})
                OR (outgoing_id = {$incoming_id} AND incoming_id ={$outgoing_id}) ORDER BY msg_id DESC";
        $query = mysqli_query($conn,$sql);
        if(mysqli_num_rows($query) > 0){
            while($row = mysqli_fetch_assoc($query)){
                if($row['incoming_id'] === $incoming_id){
                    $output .= '<div class="chat incoming">
                                   <img style="height: 35px; width: 35px;" src="php/images/'.$row['img'].'" alt="">
                                      <div class="details">
                                        <p>'.$row['msg'].'</p>
                                       </div>
                                </div>';
                }else{
                    $output .= 
                                '<div class="chat outgoing">
                                   <div class="details">
                                     <p>'.$row['msg'].' </p>
                                    </div>
                                </div>';
                }
            }
            echo $output;
        }
    }else{
        header("../login.php");
    }


?>